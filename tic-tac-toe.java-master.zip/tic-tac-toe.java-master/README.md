# Tic-tac-toe.java

A simple Tic-Tac-Toe Game written in java.

![tictactoe](http://i.imgur.com/NrtXMWJ.png)



### Features

* Image background
* Background music
* Multiplayer
* Custom icon



### Requirements

This project is built using [Netbeans IDE](https://netbeans.org/).
